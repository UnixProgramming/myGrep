#ifndef _MYERROR_H_
#define _MYERROR_H_

void printUsage();

#endif
